<?php
use Timber\Timber;

global $timberContext;
$timberContext = Timber::get_context();
ob_start();
